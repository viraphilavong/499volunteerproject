<?php
/**
 * Created by PhpStorm.
 * User: Austin
 * Date: 1/16/2017
 * Time: 7:33 PM
 */
require ("header.php");
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Registration Form</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

<div class="pic"> </div>

<br>
<p><center>Welcome to the online form HUB for First Universalist Church of Minneapolis.</center></p>
<br>
<p><center>We are located at:</center></p>
<p><center>3400 Dupont Ave. S.</center></p>
<p><center>Minneapolis, MN 55408</center></p>
<p><center>(612) 825-1701</center></p>
<br>
<p><center>Click <a href="http://www.firstuniversalistchurch.org">here</a> to return to our main website.</center></p>
<br>
<h2><center>Online Forms</center></h2>
<br>
<p><center><a href="">Child Dedication Form</a> </center></p>
<p><center><a href="">Childcare Reservation Form</a> </center></p>
<p><center><a href="">Church Communications Content Submission</a> </center></p>
<p><center><a href="">Habitat for Humanity Sign-Up Form</a> </center></p>
<p><center><a href="">Offering Plate/Community Investment Form</a> </center></p>
<p><center><a href="">Space Use Request</a> </center></p>
<p><center><a href="">Volunteering Sign-Up Form</a> </center></p>
</form>
</body>
<?php
require ("footer.php");
?>
</html>