<?php
/**
 * Created by PhpStorm.
 * User: Austin
 * Date: 1/16/2017
 * Time: 8:51 PM
 */
?>

<div id="footer">

    <h4><right>Proudly powered by SAMM</right></h4>
</div>
</body>
</html>